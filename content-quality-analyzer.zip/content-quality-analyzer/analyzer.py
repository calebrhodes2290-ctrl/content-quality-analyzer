#!/usr/bin/env python3
"""
Content Quality Analyzer
------------------------
Analyzes written content for readability, SEO health, tone, and structural
quality. Designed for freelance technical writers and content strategists.

Author : Caleb Rhodes (rhodescaleb90@gmail.com)
License: MIT
"""

import re
import sys
import math
import json
import argparse
from pathlib import Path
from collections import Counter


# ─────────────────────────────────────────────
#  TEXT UTILITIES
# ─────────────────────────────────────────────

def load_text(source: str) -> str:
    """Load text from a file path or return the string directly."""
    p = Path(source)
    if p.exists() and p.is_file():
        return p.read_text(encoding="utf-8")
    return source


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def sentences(text: str) -> list[str]:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]


def words(text: str) -> list[str]:
    return re.findall(r"[a-zA-Z']+", text.lower())


def syllable_count(word: str) -> int:
    """Estimate syllable count using a simple vowel-cluster heuristic."""
    word = word.lower().strip("'")
    if len(word) <= 3:
        return 1
    word = re.sub(r"(?<=[aeiou])es$|(?<=[^aeiou])e$", "", word)
    count = len(re.findall(r"[aeiouy]+", word))
    return max(1, count)


def paragraphs(text: str) -> list[str]:
    return [p.strip() for p in re.split(r"\n{2,}", text) if p.strip()]


# ─────────────────────────────────────────────
#  READABILITY SCORES
# ─────────────────────────────────────────────

def flesch_reading_ease(text: str) -> float:
    """
    Flesch Reading Ease (0–100).
    90–100 = Very easy | 60–70 = Standard | 0–30 = Very difficult
    """
    word_list = words(text)
    sent_list = sentences(text)
    if not word_list or not sent_list:
        return 0.0
    avg_sentence_length = len(word_list) / len(sent_list)
    avg_syllables = sum(syllable_count(w) for w in word_list) / len(word_list)
    score = 206.835 - (1.015 * avg_sentence_length) - (84.6 * avg_syllables)
    return round(max(0.0, min(100.0, score)), 1)


def flesch_kincaid_grade(text: str) -> float:
    """Flesch–Kincaid Grade Level — US school grade equivalent."""
    word_list = words(text)
    sent_list = sentences(text)
    if not word_list or not sent_list:
        return 0.0
    asl = len(word_list) / len(sent_list)
    asw = sum(syllable_count(w) for w in word_list) / len(word_list)
    grade = (0.39 * asl) + (11.8 * asw) - 15.59
    return round(max(0.0, grade), 1)


def gunning_fog(text: str) -> float:
    """Gunning Fog Index — estimates years of formal education needed."""
    word_list = words(text)
    sent_list = sentences(text)
    if not word_list or not sent_list:
        return 0.0
    complex_words = [w for w in word_list if syllable_count(w) >= 3]
    asl = len(word_list) / len(sent_list)
    pcw = len(complex_words) / len(word_list) * 100
    return round(0.4 * (asl + pcw), 1)


def reading_time_minutes(text: str, wpm: int = 238) -> float:
    """Estimated reading time at average adult reading speed (238 wpm)."""
    return round(len(words(text)) / wpm, 1)


# ─────────────────────────────────────────────
#  SEO ANALYSIS
# ─────────────────────────────────────────────

STOP_WORDS = {
    "a","an","the","and","or","but","in","on","at","to","for","of","with",
    "is","it","its","this","that","are","was","were","be","been","being",
    "have","has","had","do","does","did","will","would","could","should",
    "may","might","can","not","no","nor","so","yet","both","either","as",
    "if","then","than","too","very","just","also","about","up","out","into",
    "from","by","how","what","when","where","who","which","there","here",
    "they","them","their","we","our","you","your","i","me","my","he","she",
}


def keyword_density(text: str, top_n: int = 10) -> list[tuple[str, int, float]]:
    """Return top keywords with count and density percentage."""
    word_list = words(text)
    filtered = [w for w in word_list if w not in STOP_WORDS and len(w) > 3]
    total = len(word_list)
    counts = Counter(filtered).most_common(top_n)
    return [(w, c, round(c / total * 100, 2)) for w, c, in counts]


def passive_voice_ratio(text: str) -> float:
    """Rough passive voice detection using 'be + past participle' patterns."""
    pattern = re.compile(
        r"\b(is|are|was|were|be|been|being)\s+\w+ed\b", re.IGNORECASE
    )
    sent_list = sentences(text)
    if not sent_list:
        return 0.0
    passive = sum(1 for s in sent_list if pattern.search(s))
    return round(passive / len(sent_list) * 100, 1)


def transition_word_ratio(text: str) -> float:
    """Percentage of sentences that open with a transition word."""
    transitions = {
        "however","therefore","furthermore","moreover","additionally",
        "consequently","nevertheless","meanwhile","subsequently","notably",
        "specifically","alternatively","conversely","similarly","finally",
        "firstly","secondly","lastly","overall","in conclusion","in summary",
        "for example","for instance","as a result","in contrast","on the other hand",
    }
    sent_list = sentences(text)
    if not sent_list:
        return 0.0
    hits = sum(
        1 for s in sent_list
        if any(s.lower().startswith(t) for t in transitions)
    )
    return round(hits / len(sent_list) * 100, 1)


def heading_structure(text: str) -> dict:
    """Detect markdown headings and report structure."""
    h1 = re.findall(r"^#\s+.+", text, re.MULTILINE)
    h2 = re.findall(r"^##\s+.+", text, re.MULTILINE)
    h3 = re.findall(r"^###\s+.+", text, re.MULTILINE)
    return {"h1": len(h1), "h2": len(h2), "h3": len(h3), "titles": h1 + h2 + h3}


# ─────────────────────────────────────────────
#  STRUCTURAL METRICS
# ─────────────────────────────────────────────

def sentence_length_variety(text: str) -> dict:
    """Measure sentence length distribution — variety keeps readers engaged."""
    sent_list = sentences(text)
    if not sent_list:
        return {}
    lengths = [len(words(s)) for s in sent_list]
    avg = sum(lengths) / len(lengths)
    variance = sum((l - avg) ** 2 for l in lengths) / len(lengths)
    std_dev = math.sqrt(variance)
    short  = sum(1 for l in lengths if l <= 10)
    medium = sum(1 for l in lengths if 11 <= l <= 20)
    long_  = sum(1 for l in lengths if l > 20)
    return {
        "average_words": round(avg, 1),
        "std_deviation": round(std_dev, 1),
        "short_sentences_pct": round(short / len(lengths) * 100, 1),
        "medium_sentences_pct": round(medium / len(lengths) * 100, 1),
        "long_sentences_pct": round(long_ / len(lengths) * 100, 1),
    }


def word_count_summary(text: str) -> dict:
    word_list = words(text)
    unique = set(word_list)
    return {
        "total_words": len(word_list),
        "unique_words": len(unique),
        "lexical_diversity": round(len(unique) / len(word_list), 3) if word_list else 0,
        "total_sentences": len(sentences(text)),
        "total_paragraphs": len(paragraphs(text)),
        "reading_time_min": reading_time_minutes(text),
    }


# ─────────────────────────────────────────────
#  SCORING & GRADING
# ─────────────────────────────────────────────

def overall_score(metrics: dict) -> dict:
    """
    Compute a weighted overall content quality score (0–100).
    Weights reflect what matters most for web content.
    """
    scores = {}

    # Readability (target FRE 50–70 for professional web content)
    fre = metrics["readability"]["flesch_reading_ease"]
    if 50 <= fre <= 75:
        scores["readability"] = 100
    elif 40 <= fre < 50 or 75 < fre <= 85:
        scores["readability"] = 75
    elif 30 <= fre < 40 or 85 < fre <= 90:
        scores["readability"] = 50
    else:
        scores["readability"] = 25

    # Passive voice (< 15% is good)
    pv = metrics["seo"]["passive_voice_pct"]
    scores["active_voice"] = 100 if pv < 15 else (75 if pv < 25 else 40)

    # Transition words (10–30% is healthy)
    tw = metrics["seo"]["transition_word_pct"]
    scores["transitions"] = 100 if 10 <= tw <= 30 else (60 if tw < 10 else 70)

    # Lexical diversity (> 0.55 is good)
    ld = metrics["counts"]["lexical_diversity"]
    scores["vocabulary"] = 100 if ld > 0.55 else (70 if ld > 0.45 else 40)

    # Sentence variety (std dev > 4 is good)
    sd = metrics["sentence_variety"].get("std_deviation", 0)
    scores["sentence_variety"] = 100 if sd > 6 else (70 if sd > 4 else 40)

    weights = {
        "readability": 0.30,
        "active_voice": 0.25,
        "transitions": 0.15,
        "vocabulary": 0.15,
        "sentence_variety": 0.15,
    }

    total = sum(scores[k] * weights[k] for k in weights)
    grade = (
        "A" if total >= 85 else
        "B" if total >= 72 else
        "C" if total >= 58 else
        "D"
    )
    return {"score": round(total, 1), "grade": grade, "breakdown": scores}


# ─────────────────────────────────────────────
#  RECOMMENDATIONS
# ─────────────────────────────────────────────

def generate_recommendations(metrics: dict) -> list[str]:
    recs = []
    fre  = metrics["readability"]["flesch_reading_ease"]
    fk   = metrics["readability"]["flesch_kincaid_grade"]
    pv   = metrics["seo"]["passive_voice_pct"]
    tw   = metrics["seo"]["transition_word_pct"]
    ld   = metrics["counts"]["lexical_diversity"]
    sv   = metrics["sentence_variety"]
    wc   = metrics["counts"]["total_words"]
    hs   = metrics["headings"]

    if fre < 45:
        recs.append("⚠ Readability is low (FRE {:.0f}). Shorten sentences and replace jargon with plain language.".format(fre))
    if fre > 80:
        recs.append("ℹ Readability is very high (FRE {:.0f}). Consider adding technical depth for a professional audience.".format(fre))
    if fk > 14:
        recs.append("⚠ Grade level is {:.1f} — aim for grade 10–12 for most web audiences.".format(fk))
    if pv > 20:
        recs.append("⚠ Passive voice in {:.0f}% of sentences. Rewrite to active voice to improve clarity and engagement.".format(pv))
    if tw < 8:
        recs.append("ℹ Only {:.0f}% of sentences use transition words. Add connectors to improve flow.".format(tw))
    if ld < 0.45:
        recs.append("⚠ Lexical diversity is low ({:.2f}). Vary your vocabulary to avoid repetition.".format(ld))
    if sv.get("long_sentences_pct", 0) > 40:
        recs.append("⚠ {:.0f}% of sentences are long (>20 words). Break them up for scannability.".format(sv["long_sentences_pct"]))
    if sv.get("short_sentences_pct", 0) < 15:
        recs.append("ℹ Add more short sentences (<10 words) to create rhythm and emphasis.")
    if wc < 300:
        recs.append("ℹ Word count is low ({} words). Most indexable web content benefits from 600+ words.".format(wc))
    if hs["h2"] == 0 and wc > 400:
        recs.append("⚠ No H2 headings detected. Add subheadings to improve structure and scannability.")

    if not recs:
        recs.append("✓ Content looks well-structured. No major issues found.")
    return recs


# ─────────────────────────────────────────────
#  FULL ANALYSIS
# ─────────────────────────────────────────────

def analyze(text: str) -> dict:
    text = clean(text)
    counts   = word_count_summary(text)
    read     = {
        "flesch_reading_ease":   flesch_reading_ease(text),
        "flesch_kincaid_grade":  flesch_kincaid_grade(text),
        "gunning_fog_index":     gunning_fog(text),
    }
    seo_data = {
        "top_keywords":        keyword_density(text),
        "passive_voice_pct":   passive_voice_ratio(text),
        "transition_word_pct": transition_word_ratio(text),
    }
    sv  = sentence_length_variety(text)
    hs  = heading_structure(text)

    metrics = {
        "counts":           counts,
        "readability":      read,
        "seo":              seo_data,
        "sentence_variety": sv,
        "headings":         hs,
    }

    score = overall_score(metrics)
    recs  = generate_recommendations(metrics)

    return {**metrics, "overall": score, "recommendations": recs}


# ─────────────────────────────────────────────
#  REPORT FORMATTING
# ─────────────────────────────────────────────

def fmt_bar(value: float, max_val: float = 100, width: int = 30) -> str:
    filled = int((value / max_val) * width)
    return "█" * filled + "░" * (width - filled)


def print_report(result: dict, source_label: str = "input") -> None:
    SEP  = "─" * 60
    SEP2 = "═" * 60

    print(f"\n{SEP2}")
    print(f"  CONTENT QUALITY ANALYZER  ·  Caleb Rhodes")
    print(f"{SEP2}")
    print(f"  Source : {source_label}")
    print(f"{SEP}\n")

    # Overall
    o = result["overall"]
    print(f"  OVERALL SCORE   {o['score']}/100   Grade: {o['grade']}")
    print(f"  {fmt_bar(o['score'])}\n")

    sub = o["breakdown"]
    for label, val in sub.items():
        print(f"  {label:<22} {val:>3}/100  {fmt_bar(val, width=20)}")
    print()

    # Counts
    c = result["counts"]
    print(f"{SEP}")
    print(f"  DOCUMENT STATS")
    print(f"{SEP}")
    print(f"  Words          : {c['total_words']:,}")
    print(f"  Unique words   : {c['unique_words']:,}  (diversity {c['lexical_diversity']})")
    print(f"  Sentences      : {c['total_sentences']}")
    print(f"  Paragraphs     : {c['total_paragraphs']}")
    print(f"  Reading time   : {c['reading_time_min']} min\n")

    # Readability
    r = result["readability"]
    print(f"{SEP}")
    print(f"  READABILITY")
    print(f"{SEP}")
    print(f"  Flesch Reading Ease  : {r['flesch_reading_ease']}  ", end="")
    fre = r['flesch_reading_ease']
    if fre >= 70:   print("(Easy)")
    elif fre >= 50: print("(Standard)")
    elif fre >= 30: print("(Difficult)")
    else:           print("(Very Difficult)")
    print(f"  Flesch-Kincaid Grade : {r['flesch_kincaid_grade']}  (US grade level)")
    print(f"  Gunning Fog Index    : {r['gunning_fog_index']}\n")

    # Sentence variety
    sv = result["sentence_variety"]
    print(f"{SEP}")
    print(f"  SENTENCE STRUCTURE")
    print(f"{SEP}")
    print(f"  Avg words/sentence : {sv.get('average_words', 'N/A')}")
    print(f"  Std deviation      : {sv.get('std_deviation', 'N/A')}  (higher = more variety)")
    print(f"  Short  (≤10 words) : {sv.get('short_sentences_pct', 0)}%")
    print(f"  Medium (11–20)     : {sv.get('medium_sentences_pct', 0)}%")
    print(f"  Long   (>20 words) : {sv.get('long_sentences_pct', 0)}%\n")

    # SEO
    s = result["seo"]
    print(f"{SEP}")
    print(f"  SEO & STYLE")
    print(f"{SEP}")
    print(f"  Passive voice    : {s['passive_voice_pct']}%  (target < 15%)")
    print(f"  Transition words : {s['transition_word_pct']}%  (target 10–30%)")
    h = result["headings"]
    print(f"  Headings found   : H1={h['h1']}  H2={h['h2']}  H3={h['h3']}\n")

    print(f"  Top Keywords:")
    for word, count, density in s["top_keywords"][:7]:
        print(f"    {word:<20} {count:>4}x   {density:.2f}%")
    print()

    # Recommendations
    print(f"{SEP}")
    print(f"  RECOMMENDATIONS")
    print(f"{SEP}")
    for rec in result["recommendations"]:
        print(f"  {rec}")
    print(f"\n{SEP2}\n")


# ─────────────────────────────────────────────
#  CLI
# ─────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="analyzer",
        description="Content Quality Analyzer — readability, SEO, tone & structure.",
    )
    p.add_argument(
        "source",
        nargs="?",
        default=None,
        help="Path to a .txt / .md file, or paste text directly (wrap in quotes).",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Output full results as JSON instead of the formatted report.",
    )
    p.add_argument(
        "--sample",
        action="store_true",
        help="Run the built-in sample article for a quick demo.",
    )
    return p


SAMPLE_TEXT = """
# How Transformer Models Changed Natural Language Processing

Natural language processing has undergone a fundamental transformation over the past decade.
The introduction of transformer architectures in 2017 made previous state-of-the-art methods
almost immediately obsolete. Today, models like GPT-4, Claude, and Gemini are built on
variations of this architecture.

## What makes transformers different?

Earlier NLP systems processed text sequentially — one word at a time, left to right.
This created a bottleneck. Long-range dependencies in text, where a pronoun near the end
of a paragraph refers to a noun several sentences earlier, were difficult to capture.

Transformers solved this with the attention mechanism. Instead of reading text sequentially,
attention allows the model to weigh every word against every other word simultaneously.
The word "it" in a sentence can directly attend to "transformer" three sentences back.
This is computationally expensive but enormously powerful.

## Why does this matter for content writers?

Understanding how these models process text changes how we write for AI-augmented workflows.
Models respond to structure, specificity, and context. Vague prompts produce vague output.
Precise, well-structured inputs — with clear context and constraints — produce usable results.

Furthermore, as AI tools become embedded in editorial workflows, writers who understand
the underlying mechanics will adapt faster. They will know when to trust the output and
when to interrogate it. Consequently, technical literacy is rapidly becoming a core
skill for content professionals, not just a nice-to-have.
"""


def main():
    parser = build_parser()
    args   = parser.parse_args()

    if args.sample:
        text   = SAMPLE_TEXT
        label  = "built-in sample article"
    elif args.source:
        text   = load_text(args.source)
        label  = args.source
    else:
        print("Paste your content below. Press Enter twice then Ctrl+D (Mac/Linux) or Ctrl+Z (Windows) when done.\n")
        try:
            text = sys.stdin.read()
        except KeyboardInterrupt:
            print("\nCancelled.")
            sys.exit(0)
        label = "stdin"

    if not text.strip():
        print("Error: no content provided.")
        sys.exit(1)

    result = analyze(text)

    if args.json:
        # Remove non-serializable bits cleanly
        out = {k: v for k, v in result.items() if k != "seo"}
        out["seo"] = {
            "top_keywords": [
                {"word": w, "count": c, "density_pct": d}
                for w, c, d in result["seo"]["top_keywords"]
            ],
            "passive_voice_pct":   result["seo"]["passive_voice_pct"],
            "transition_word_pct": result["seo"]["transition_word_pct"],
        }
        print(json.dumps(out, indent=2))
    else:
        print_report(result, source_label=label)


if __name__ == "__main__":
    main()
