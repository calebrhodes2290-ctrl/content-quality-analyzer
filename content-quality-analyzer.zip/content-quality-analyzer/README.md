# Content Quality Analyzer

A zero-dependency Python CLI tool that audits written content for readability, SEO health, tone, and structural quality — built for freelance technical writers, content strategists, and anyone producing web copy at scale.

---

## Why I built this

As a freelance content writer producing technical articles, API docs, and SEO copy across multiple clients, I found myself running the same mental checklist on every draft:

- Is the reading level right for this audience?
- Am I leaning on passive voice too much?
- Are my sentences varied enough to keep people reading?
- What keywords am I actually repeating?

This tool automates that checklist and scores the result, so feedback is consistent and objective rather than instinctive.

---

## Features

| Category | What it measures |
|---|---|
| **Readability** | Flesch Reading Ease, Flesch–Kincaid Grade Level, Gunning Fog Index |
| **SEO** | Keyword density (top 10), passive voice ratio, transition word usage |
| **Structure** | Sentence length distribution, heading hierarchy (H1/H2/H3), lexical diversity |
| **Overall Score** | Weighted 0–100 score with letter grade and per-dimension breakdown |
| **Recommendations** | Plain-English improvement suggestions tailored to the content |

---

## Quick start

No dependencies required — runs on Python 3.10+.

```bash
git clone https://github.com/calebrhodeswriter/content-quality-analyzer.git
cd content-quality-analyzer
```

### Run the built-in demo

```bash
python analyzer.py --sample
```

### Analyze a file

```bash
python analyzer.py my_article.txt
python analyzer.py my_article.md
```

### Paste text directly

```bash
python analyzer.py "Your article text goes here as a quoted string."
```

### Pipe from stdin

```bash
cat my_draft.txt | python analyzer.py
```

### JSON output (for integration with other tools)

```bash
python analyzer.py my_article.txt --json
```

---

## Sample output

```
════════════════════════════════════════════════════════════
  CONTENT QUALITY ANALYZER  ·  Caleb Rhodes
════════════════════════════════════════════════════════════
  Source : samples/transformer_article.txt
────────────────────────────────────────────────────────────

  OVERALL SCORE   81.2/100   Grade: B

  readability            100/100  ████████████████████
  active_voice            75/100  ███████████████░░░░░
  transitions            100/100  ████████████████████
  vocabulary              70/100  ██████████████░░░░░░
  sentence_variety       100/100  ████████████████████

────────────────────────────────────────────────────────────
  DOCUMENT STATS
────────────────────────────────────────────────────────────
  Words          : 312
  Unique words   : 196  (diversity 0.628)
  Sentences      : 21
  Paragraphs     : 4
  Reading time   : 1.3 min

────────────────────────────────────────────────────────────
  READABILITY
────────────────────────────────────────────────────────────
  Flesch Reading Ease  : 58.3  (Standard)
  Flesch-Kincaid Grade : 11.4  (US grade level)
  Gunning Fog Index    : 14.1

────────────────────────────────────────────────────────────
  RECOMMENDATIONS
────────────────────────────────────────────────────────────
  ℹ Lexical diversity is low (0.43). Vary your vocabulary to avoid repetition.
════════════════════════════════════════════════════════════
```

---

## How the overall score is calculated

The 0–100 score is a weighted average across five dimensions:

| Dimension | Weight | Target |
|---|---|---|
| Readability (Flesch RE) | 30% | 50–75 for professional web content |
| Active voice | 25% | < 15% passive sentences |
| Transition words | 15% | 10–30% of sentences |
| Vocabulary richness | 15% | Lexical diversity > 0.55 |
| Sentence variety | 15% | Std deviation > 6 words |

Weights reflect what matters most for content that is readable, indexable, and engaging.

---

## Readability benchmarks

| Flesch Reading Ease | Audience |
|---|---|
| 90–100 | Very easy — 5th grade |
| 70–90 | Easy — middle school |
| 50–70 | Standard — high school / professional web |
| 30–50 | Difficult — academic / technical |
| 0–30 | Very difficult — legal / scientific |

Most web content performs best in the **50–70** range.

---

## Sample files

The `samples/` directory contains three test articles at different quality levels:

| File | Description |
|---|---|
| `samples/high_quality.md` | Strong technical article — grade A baseline |
| `samples/passive_heavy.txt` | Passive voice–saturated draft — before/after demo |
| `samples/seo_article.md` | SEO-optimized piece with keyword targeting |

---

## Project background

Built and maintained by **Caleb Rhodes**, a California-based freelance content writer and AI specialist. I've written technical documentation, long-form guides, and SEO content for software companies and AI platforms since 2016.

This project reflects the same methodology I apply when auditing client drafts — formalized into repeatable, objective code.

**Contact:** rhodescaleb90@gmail.com  
**Portfolio:** [calebrhodeswriter.github.io](https://calebrhodeswriter.github.io)

---

## License

MIT — free to use, adapt, and build on.
